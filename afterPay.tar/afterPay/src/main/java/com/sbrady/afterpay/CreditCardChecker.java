package com.sbrady.afterpay;

import com.sbrady.afterpay.model.FraudId;
import com.sbrady.afterpay.utils.ArrayChunker;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class CreditCardChecker {

    private ArrayChunker arrayChunker;

    public CreditCardChecker(ArrayChunker arrayChunker) {
        this.arrayChunker = arrayChunker;
    }

    public Set<String> findFraudulentTransactions(BigDecimal threshold, String transactions) {

        List<List<String>> chunks = getChunks(transactions);

        return geFraudulentCreditCards(threshold, chunks);
    }

    private Set<String> geFraudulentCreditCards(BigDecimal threshold, List<List<String>> chunks) {
        return getFraudIdBigDecimalHashMap(chunks)
                .entrySet()
                .stream()
                .filter((e) -> isFraudulent(threshold, e))
                .map((e) -> e.getKey().getCreditCardNumber())
                .collect(Collectors.toSet());
    }

    private boolean isFraudulent(BigDecimal threshold, Map.Entry<FraudId, BigDecimal> e) {
        return e.getValue().compareTo(threshold) > 0;
    }

    private HashMap<FraudId, BigDecimal> getFraudIdBigDecimalHashMap(List<List<String>> chunks) {
        HashMap<FraudId, BigDecimal> transactionTotals = new HashMap<>();
        chunks.forEach(chunk -> {
            FraudId key = new FraudId(chunk.get(1), chunk.get(0));

            BigDecimal value = new BigDecimal(chunk.get(2));

            BigDecimal sum = transactionTotals.get(key);
            if (sum != null) {
                transactionTotals.put(key, sum.add(value));
            } else {
                transactionTotals.put(key, value);
            }

        });
        return transactionTotals;
    }

    private List<List<String>> getChunks(String transactions) {
        List<String> split = splitItems(transactions);
        return arrayChunker.toChunks(split);
    }

    private List<String> splitItems(String transactions) {
        return Arrays.stream(transactions
                .split(","))
                .map(String::trim).collect(Collectors.toList());
    }

}
