package com.sbrady.afterpay.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayChunker {
    private int chuckSize;

    public ArrayChunker(int chuckSize) {
        this.chuckSize = chuckSize;
    }

    public List<List<String>> toChunks(List<String> input) {
        String[] inputArr = asArray(input);

        return chunkToList(input, inputArr);
    }

    private List<List<String>> chunkToList(List<String> input, String[] inputArr) {
        List<List<String>> results = new ArrayList<>();
        for (int i = 0; i < input.size(); i += chuckSize) {
            String[] chunk = Arrays.copyOfRange(inputArr, i, Math.min(input.size(), i + chuckSize));
            results.add(Arrays.asList(chunk));
        }
        return results;
    }

    private String[] asArray(List<String> input) {
        String[] inputArr = new String[input.size()];
        inputArr = input.toArray(inputArr);
        return inputArr;
    }
}
