package com.sbrady.afterpay;

import com.sbrady.afterpay.utils.ArrayChunker;

import java.math.BigDecimal;
import java.util.Set;

public class CreditCardCheckMain {

    private static BigDecimal THRESHOLD = new BigDecimal("9.0");

    public static void main(String[] args){
        System.out.println("Fraud Detector!!!");
        CreditCardChecker creditCardChecker = new CreditCardChecker(new ArrayChunker(3));

        Set<String> fraudulent = creditCardChecker.findFraudulentTransactions(THRESHOLD, args[0]);

        System.out.println("the Following are fraudulent:");
        fraudulent.forEach(System.out::println);
    }
}
