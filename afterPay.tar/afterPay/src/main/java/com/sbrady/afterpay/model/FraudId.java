package com.sbrady.afterpay.model;

import java.util.Objects;

public class FraudId {

    private final String date;
    private final String creditCardNumber;

    public FraudId(String date, String creditCardNumber){
        this.date = date.split("T")[0];
        this.creditCardNumber = creditCardNumber;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FraudId fraudId = (FraudId) o;
        return Objects.equals(date, fraudId.date) &&
                Objects.equals(creditCardNumber, fraudId.creditCardNumber);
    }

    @Override
    public int hashCode() {

        return Objects.hash(date, creditCardNumber);
    }
}
