package com.sbrady.afterpay.model;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class FraudIdTest {


    @Test
    public void itIsUniquePerDayAndCardNumber(){
        Set<FraudId> fraudIdSet = new HashSet<>();
        FraudId cc1 = new FraudId("2014-04-29T13:15:54", "cc1");
        fraudIdSet.add(cc1);
        fraudIdSet.add(new FraudId("2014-04-29T13:15:54", "cc1"));
        fraudIdSet.add(new FraudId("2014-04-29T00:00:00", "cc1"));
        FraudId cc2 = new FraudId("2014-04-29T00:00:00", "cc2");
        fraudIdSet.add(cc2);

        assertThat(fraudIdSet.size(), is(2));

        assertTrue(fraudIdSet.contains(cc1));
        assertTrue(fraudIdSet.contains(cc2));
    }


}