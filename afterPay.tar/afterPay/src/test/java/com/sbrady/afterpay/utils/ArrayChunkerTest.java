package com.sbrady.afterpay.utils;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ArrayChunkerTest {

    private ArrayChunker arrayChunker;

    @Before
    public void setUp() throws Exception {
        arrayChunker = new ArrayChunker(3);
    }


    @Test
    public void itPutsAnArrayIntoEqualParts(){
        List<String> input = Arrays.asList("1","2","3","4","5","6");

        List<List<String>> results = arrayChunker.toChunks(input);

        List<List<String>> expected = Arrays.asList( Arrays.asList("1","2","3"), Arrays.asList("4","5","6"));

        assertThat(results, is(expected));
    }
}