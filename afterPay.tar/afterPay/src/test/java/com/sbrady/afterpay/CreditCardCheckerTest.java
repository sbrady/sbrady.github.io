package com.sbrady.afterpay;

import com.sbrady.afterpay.utils.ArrayChunker;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class CreditCardCheckerTest {

    private CreditCardChecker creditCardChecker;

    @Before
    public void setUp() {
        creditCardChecker = new CreditCardChecker(new ArrayChunker(3));
    }


    @Test
    public void findFraudulentTransactionsWhenOneTransactionThereIsNoFraud() {
        Set<String> hasedCreditCardNumbers = creditCardChecker.findFraudulentTransactions(
                new BigDecimal("11"), "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 10.00");
        assertThat(hasedCreditCardNumbers.size(), is(0));
    }


    @Test
    public void findFraudulentTransactionsWhenOneTransactionIsAboveThreshold() {
        Set<String> hasedCreditCardNumbers = creditCardChecker.findFraudulentTransactions(new BigDecimal(2),
                "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 10.00");

        assertThat(hasedCreditCardNumbers.size(), is(1));
        assertThat(hasedCreditCardNumbers.iterator().next(), is("10d7ce2f43e35fa57d1bbf8b1e2"));
    }

    @Test
    public void findFraudulentTransactionsWhenTheSumOfManyIsAboveThreshold() {
        Set<String> hasedCreditCardNumbers = creditCardChecker.findFraudulentTransactions(new BigDecimal(11),
                "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 5.00," +
                        "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 7.00," +
                        "123123OK12312, 2014-04-29T13:15:54, 7.00");

        assertThat(hasedCreditCardNumbers.size(), is(1));
        assertThat(hasedCreditCardNumbers.iterator().next(), is("10d7ce2f43e35fa57d1bbf8b1e2"));
    }

    @Test
    public void findFraudulentTransactionsWhenTheSumIsTheSameThresholdMany() {
        Set<String> hasedCreditCardNumbers = creditCardChecker.findFraudulentTransactions(new BigDecimal(11),
                "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 5.00," +
                        "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 6.00");

        assertThat(hasedCreditCardNumbers.size(), is(0));
    }

    @Test
    public void findFraudulentTransactionsWhenTheSumOfManyIsAboveThresholdWithDifferentTime() {
        Set<String> hasedCreditCardNumbers = creditCardChecker.findFraudulentTransactions(new BigDecimal(11),
                "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T13:15:54, 5.00," +
                        "10d7ce2f43e35fa57d1bbf8b1e2, 2014-04-29T14:15:54, 10.00");

        assertThat(hasedCreditCardNumbers.size(), is(1));
        assertThat(hasedCreditCardNumbers.iterator().next(), is("10d7ce2f43e35fa57d1bbf8b1e2"));
    }


}